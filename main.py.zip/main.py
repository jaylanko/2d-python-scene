import glfw
import OpenGL.GL
from OpenGL.GL import *

from OpenGL.GL import glBegin, glEnd
from math import sin, cos, pi

from OpenGL.raw.GL.VERSION.GL_1_0 import glVertex2f

WIDTH, HEIGHT = 800, 600

# Define the window variable as a global variable
window = None


def display():
    global window  # Use the global window variable
    glClear(GL_COLOR_BUFFER_BIT)
    # Draw a circle
    sides = 50
    radius = 0.22
    x, y = 0.7, 0.7
    OpenGL.GL.glBegin(OpenGL.GL.GL_POLYGON)
    OpenGL.GL.glColor3f(1.0, 1.0, 0.0)  # Red
    for i in range(sides):
        angle = 2 * pi * i / sides
        glVertex2f(x + radius * cos(angle), y + radius * sin(angle))
    OpenGL.GL.glEnd()

    # Draw a square with a vertical, horizontal, and diagonal line inside
    glBegin(OpenGL.GL.GL_POLYGON)
    glColor3f(0.82, 0.41, 0.11)  # Blue
    glVertex2f(-1, -0.8)  # Top-left
    glVertex2f(1, -0.8)  # Top-right
    glVertex2f(1, -1)  # Bottom-right
    glVertex2f(-1, -1)  # Bottom-left
    glEnd()

    #square house
    glBegin(OpenGL.GL.GL_POLYGON)
    glColor3f(0.82, 0.70, 0.54)  # Blue
    glVertex2f(-0.8, -0.8)  # Top-left
    glVertex2f(-0.2, -0.8)  # Top-right
    glVertex2f(-0.2, -0.1)  # Bottom-right
    glVertex2f(-0.8, -0.1)  # Bottom-left
    glEnd()

    # door
    glBegin(OpenGL.GL.GL_POLYGON)
    glColor3f(0.0, 0.00, 0.00)  # Blue
    glVertex2f(-0.6, -0.8)  # Top-left
    glVertex2f(-0.4, -0.8)  # Top-right
    glVertex2f(-0.4, -0.4)  # Bottom-right
    glVertex2f(-0.6, -0.4)  # Bottom-left
    glEnd()

    #roof
    glBegin(GL_TRIANGLES);
    glColor3f(0.0, 0.0, 0.0)  # Blue
    glVertex2f(-0.86, -0.1);
    glVertex2f(-0.13, -0.1);
    glVertex2f(-0.48, 0.35);
    glEnd();



    # tree root
    glBegin(OpenGL.GL.GL_POLYGON)
    glColor3f(0.54, 0.27, 0.07)  # Blue
    glVertex2f(0.4, -0.8)  # Top-left
    glVertex2f(0.3, -0.8)  # Top-right
    glVertex2f(0.3, -0.2)  # Bottom-right
    glVertex2f(0.4, -0.2)  # Bottom-left
    glEnd()

    # circle tree
    sides = 50
    radius = 0.28
    x, y = 0.36, -0.1
    OpenGL.GL.glBegin(OpenGL.GL.GL_POLYGON)
    OpenGL.GL.glColor3f(0.0, 1.0, 0.0)  # Red
    for i in range(sides):
        angle = 2 * pi * i / sides
        glVertex2f(x + radius * cos(angle), y + radius * sin(angle))
    OpenGL.GL.glEnd()

    # Swap buffers
    glfw.swap_buffers(window)


def main():
    global window  # Use the global window variable

    # Initialize GLFW
    if not glfw.init():
        return

    # Create a window and make the context current
    window = glfw.create_window(WIDTH, HEIGHT, "PyOpenGL Example", None, None)
    if not window:
        glfw.terminate()
        return
    glfw.make_context_current(window)

    # Set the background color
    OpenGL.GL.glClearColor(0.67, 0.84, 0.90, 0.0)

    # Set the display function
    glfw.set_window_size_callback(window, display)

    # Run the event loop
    while not glfw.window_should_close(window):
        # Poll for events
        glfw.poll_events()

        # Render the scene
        display()

    # Terminate GLFW
    glfw.terminate()


if __name__ == '__main__':
    main()
